<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">
</head>
<body>
    
    <?php echo $__env->make('navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="container text-center mt-5">
        <h2>Welcome to Your Dashboard</h2>
        <p>Manage your files, edit your profile, and view users.</p>
    </div>
</body>
</html>
<?php /**PATH C:\Users\LENOVO\Documents\web_system\aguelo_laravel2025\resources\views/dashboard.blade.php ENDPATH**/ ?>