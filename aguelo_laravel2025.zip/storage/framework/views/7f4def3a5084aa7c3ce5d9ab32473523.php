<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User List</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
</head>

<body>
    <?php echo $__env->make('navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="container-fluid py-4">
        <h2 class="text-center mb-4">User List</h2>

        <form method="GET" action="<?php echo e(route('user.list')); ?>" class="mb-4">
            <h4>Search Users</h4>
            <div class="row g-2">
                <div class="col-md-4">
                    <input type="text" name="name" placeholder="Search by name" value="<?php echo e(request('name')); ?>" class="form-control">
                </div>
                <div class="col-md-4">
                    <input type="text" name="email" placeholder="Search by email" value="<?php echo e(request('email')); ?>" class="form-control">
                </div>
                <div class="col-md-4 d-flex gap-2">
                    <button type="submit" class="btn btn-primary">Filter</button>
                    <?php if(request('name') || request('email')): ?>
                        <a href="<?php echo e(route('user.list')); ?>" class="btn btn-secondary">Clear Filters</a>
                    <?php endif; ?>
                </div>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-bordered w-100">
                <thead class="table-light">
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->username); ?></td>
                            <td><?php echo e($user->user_type); ?></td>
                            <td>
                                <button class="btn btn-sm btn-primary">Edit</button>
                                <button class="btn btn-sm btn-danger">Delete</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center">No users found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="d-flex justify-content-center mt-3">
            <?php echo e($users->links()); ?>

        </div>

        <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary w-100 mt-3">Back to Dashboard</a>
    </div>
</body>

</html>
<?php /**PATH C:\Users\LENOVO\Documents\web_system\aguelo_laravel2025\resources\views/user-list.blade.php ENDPATH**/ ?>